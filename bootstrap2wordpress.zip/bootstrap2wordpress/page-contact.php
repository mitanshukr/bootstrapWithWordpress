<?php
/*
Template Name: Contact Page
*/
get_header();
$thumbnail_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ));
$contact_paragraph = get_field('contact_paragraph');
$address = get_field('address');
$phone_no = get_field('phone_no');
$facebook_url = get_field('facebook_url');
$instagram_url = get_field('instagram_url');
$twitter_url = get_field('twitter_url');
?>

<!-- Head Parallex -->
<?php if(has_post_thumbnail()) { ?>
    <section class="feature-image" style="background: url('<?php echo $thumbnail_url; ?>') no-repeat; background-size: cover;" data-type="background" data-speed="2">
          <h1 class="page-title"><?php the_title(); ?></h1>
    </section>
 <?php } else { ?>
    <section class="feature-image feature-image-default" data-type="background" data-speed="2">
          <h1 class="page-title"><?php the_title(); ?></h1>
    </section>
 <?php } ?>

<!-- main section -->
<div class="container">
      <div class="row mt-md-5 mb-sm-0 mb-3" id="primary">
        
            <p class="col-sm-4">
                <?php if(!empty($contact_paragraph)) { echo $contact_paragraph; } ?>
            </p>
          
            <main class="col-sm-7 offset-sm-1" id="contact-form">
                     <?php the_content(); ?>
            </main>
      </div>
    <hr>
    <div class="row mt-5 mb-5" id="contact-details">
        <div class="col-md offset-md-1 mb-md-0 mb-3" id="contact-address">
            <?php if(!empty($address)) : ?>
                <h4>Head Office:</h4>
            <?php echo $address;
            endif; 
            if(!empty($phone_no)) : ?>
            <p><strong>Contact us:</strong><?php echo $phone_no; ?></p>
            <?php endif; ?>
        </div>
        <?php if(!empty($facebook_url) || !empty($instagram_url) || !empty($twitter_url)) : ?>
        <div class="col-md" id="contact-social">
            <h4>Follow us on Social Media:</h4>
            <?php if(!empty($facebook_url)) : ?>
            <a href="<?php echo $facebook_url; ?>"><i class="fa fa-facebook-official"></i>Facebook</a>
            <?php endif;
            if(!empty($instagram_url)) : ?>
            <a href="<?php echo $instagram_url; ?>"><i class="fa fa-instagram"></i>Instagram</a>
            <?php endif;
            if(!empty($twitter_url)) : ?>
            <a href="<?php echo $twitter_url; ?>"><i class="fa fa-twitter"></i>Twitter</a>
            <?php endif; endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>