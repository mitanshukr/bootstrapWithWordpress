<?php
//Custom Fields
$optin_text = get_post_meta( 25, 'optin_text', true);
$optin_btn_text = get_post_meta( 25, 'optin_btn_text', true);
?>

<!-- Opt in Section -->
<section id="optin">
        <div class="container">
          <div class="row">
            <div class="col-sm-8">
              <p class="lead"><?php echo $optin_text ?></p>
            </div>
            <div class="col-sm-4">
              <button class="btn btn-lg btn-block btn-success" data-toggle="modal" data-target="#myModal"><?php echo $optin_btn_text ?></button>
            </div>
          </div>
        </div>
      </section>