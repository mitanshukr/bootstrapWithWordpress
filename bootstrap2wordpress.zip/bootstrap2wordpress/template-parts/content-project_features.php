<?php
//Adv custom Fields
$final_project_title = get_field('final_project_title');
$final_project_description = get_field('final_project_description');

?>

<!-- Project Features -->
      <section id="project-features" class="text-center">
        <div class="container">
          <h2><?php echo $final_project_title; ?></h2>

          <?php if( !empty($final_project_description)) : ?>
              <p class="lead"><?php echo $final_project_description; ?></p>
          <?php endif; ?>

          <div class="row">
            <?php $loop = new WP_Query(array('post_type' => 'project_features', 'orderby' => 'post_id', 'order' => 'ASC')); ?>

            <?php while($loop->have_posts()):$loop->the_post(); ?>
            <div class="col-sm-4">
              <?php
                if(has_post_thumbnail()){
                      the_post_thumbnail();
                } ?>

              <h3><?php the_title(); ?></h3>
              <p><?php the_content(); ?></p>

            </div>
            <?php endwhile; wp_reset_query(); ?>

          </div>
        </div>
      </section>