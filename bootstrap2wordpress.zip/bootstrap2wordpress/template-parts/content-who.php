<?php
//Advanced Custom Fields
$who_feature_image = get_field('who_feature_image');
$who_title = get_field('who_title');
$who_section_body = get_field('who_section_body');
?>

<!-- Who Benefits -->
<section id="who-benefits">
<div class="container">
    <div class="section-header text-center">
    <img src="<?php echo $who_feature_image['url']; ?>" alt="<?php echo $who_feature_image['alt']; ?>">
    <h2><?php echo $who_title; ?></h2>
    </div>
    <div class="row">
    <div class="col-sm-8 offset-sm-2">
    <?php echo $who_section_body; ?>
    </div>
    </div>
</div>
</section>