<?php
//Advanced Custom feilds

$income_feature_image = get_field('feature_image');
$income_title = get_field('title');
$income_description = get_field('description');
$region1_title = get_field('region1_title');
$region1_description = get_field('region1_description');
$region2_title = get_field('region2_title');
$region2_description = get_field('region2_description');

?>

<!-- Boost your Income -->
<section id="boost-income ">
        <div class="container">
          <div class="section-header text-center">
            <?php if( !empty($income_feature_image)) : ?>
            <img src="<?php echo $income_feature_image['url']; ?>" alt="<?php echo $income_feature_image['alt']; ?>">
            <?php endif; ?>

            <h2><?php echo $income_title ?></h2>
          </div>
          <p class="lead"><?php echo $income_description ?></p>
          <div class="row">
            <div class="col-sm-6">
              <h3><?php echo $region1_title ?></h3>
              <p><?php echo $region1_description ?></p>
            </div>
            <div class="col-sm-6">
              <h3><?php echo $region2_title ?></h3>
              <p><?php echo $region2_description ?></p>
            </div>
          </div>
        </div>
      </section>