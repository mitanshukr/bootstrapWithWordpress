<?php
//adv custom fields
$featurette_title = get_field('featurette_title');
$featurette_url = get_field('featurette_url');
?>

<!-- Video Featurette -->
<section id="featurette" class="m-auto text-center">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 offset-sm-2">
              <h2><?php echo $featurette_title; ?></h2>
              <iframe class="mt-4" width="100%" height="415" src="<?php echo $featurette_url; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
        </div>
      </section>