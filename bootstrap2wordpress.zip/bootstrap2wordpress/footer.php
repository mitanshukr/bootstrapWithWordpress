<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Bootstrap_to_Wordpress
 */

?>

<?php wp_footer(); ?>
<!-- Sign Up Section -->
<section id="signup" data-type="background" data-speed="4">
        <div class="container">
          <div class="row">
            <div class="col-sm-6 offset-sm-3">
              <h2>Are you ready to take your coding skills to the <strong>next level</strong>?</h2>
              <p><a href="" class="btn btn-lg btn-block btn-success">Yes, sign me up!</a></p>
            </div><!-- end col -->
          </div><!-- row -->
        </div><!-- container -->
      </section><!-- signup -->

      <!-- Footer -->
      <footer>
		<div class="container">
      <div class="row">
        <div class="col-sm-3">
          <p><a href="/"><img src="<?php bloginfo('template_directory'); ?>/assets/img/logo.png" alt="Bootstrap to WordPress"></a></p>
        </div><!-- end col -->
        <div class="col-sm-6 text-center">
          
          <?php
						wp_nav_menu( array(
							'theme_location'	=> 'menu-2',
							'container'			=> 'nav',
              'menu_class'		=> 'list-unstyled list-inline',
              'add_li_class'  => 'list-inline-item',
							'walker'        => new WP_Bootstrap_Navwalker(),
						) );

					?>
        </div><!-- end col -->
        <div class="col-sm-3">
          <p class="float-right">&copy; 2014 Brad Hussey</p>
        </div><!-- end col -->
      </div>
		</div><!-- container -->
	</footer>

<!-- Modal -->
<div class="modal fade" id="myModal" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="myModalLabel"><i class="fa fa-envelope"></i> Subscribe to our Mailing List.</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
        </button>
      </div>
      <div class="modal-body">
        Simply enter your name and email! As a thank you gift for joining us, We're going to give you one of our best-selling courses,<em> for free!</em>
        <form class="form-inline mt-3" role="form">
          <div class="form-group">
            <label class="sr-only" for="subscribe-name">Your First Name</label>
            <input type="text" class="form-control mr-2" id="subscribe-name" placeholder="Your first Name">
          </div>
          <div class="form-group">
            <label class="sr-only" for="subscribe-email">Your Email Address</label>
            <input type="email" class="form-control mr-2" id="subscribe-email" placeholder="Your Email address" aria-describedby="emailHelp">
          </div>
          <a type="submit" class="btn btn-danger" value="Subscribe">Subscribe!</a>
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </form>
        <hr>
        <p><small>By providing your email you consent to receiving occasional promotional emails &amp; you may unsubscribe at any time.
          <br>No Spam. Promise!
        </small></p>
      </div>
    </div>
  </div>
</div>

 <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <!-- 
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/assets/js/bootstrap.bundle.js"></script>
     <script src="<?php bloginfo('template_directory'); ?>/assets/js/main.js" type="text/javascript"></script>

    <!-- TypeKit Fonts
    <script type="text/javascript" src="//use.typekit.net/gla7wnd.js"></script>
	<script type="text/javascript">try{Typekit.load();}catch(e){}</script> -->

</body>
</html>
